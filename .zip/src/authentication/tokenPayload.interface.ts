interface TokenPayload {
  userId: string;
}

export default TokenPayload;
