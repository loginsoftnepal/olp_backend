export class ReturnCreateAdminDto {
  username: string;
  password: string;
  createdAt: Date;
}
