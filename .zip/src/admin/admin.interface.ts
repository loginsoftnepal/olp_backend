import Admin from './admin.entity';

export interface RequestwithAdmin {
  admin: Admin;
}
