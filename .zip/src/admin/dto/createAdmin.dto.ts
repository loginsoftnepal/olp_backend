export default class CreateAdminDto {
  username: string;
  password: string;
  email: string;
}
