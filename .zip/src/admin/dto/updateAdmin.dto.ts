export class UpdateAdminDto {
  username: string;
  password: string;
  email: string;
}
