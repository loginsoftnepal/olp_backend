export class DeleteAdminDto {
  adminId: string;
}
