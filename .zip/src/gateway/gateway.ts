// import { Inject, Injectable, UseGuards } from '@nestjs/common';
// import {
//   ConnectedSocket,
//   MessageBody,
//   OnGatewayConnection,
//   OnGatewayDisconnect,
//   SubscribeMessage,
//   WebSocketGateway,
//   WebSocketServer,
// } from '@nestjs/websockets';
// import { WsAuthGuard } from 'src/authentication/ws-auth.guard';
// import { GatewaySessionManager } from './gateway.session';
// import { AuthenticatedSocket } from 'src/utils/interfaces';
// import { Server } from 'socket.io';
// import { OnEvent } from '@nestjs/event-emitter';

// @WebSocketGateway()
// @UseGuards(WsAuthGuard)
// export class MessagingGateway
//   implements OnGatewayConnection, OnGatewayDisconnect
// {
//   constructor(private readonly sessionManager: GatewaySessionManager) {}

//   @WebSocketServer()
//   server: Server;

//   handleConnection(socket: AuthenticatedSocket, ...args: any[]) {
//     console.log('Incoming connection');
//     this.sessionManager.setUserSocket(socket.user.id, socket);
//     socket.emit('connected', {});
//   }

//   handleDisconnect(socket: AuthenticatedSocket) {
//     console.log('handle Disconnect');
//     console.log(`${socket.user.username} disconnected`);
//     this.sessionManager.removeUserSocket(socket.user.id);
//   }

//   @SubscribeMessage('createMessage')
//   handleCreateMessage(@MessageBody() data: any) {
//     console.log('Create Message');
//   }

//   @SubscribeMessage('onTypingStart')
//   onTypingStart(
//     @MessageBody() data: any,
//     @ConnectedSocket() client: AuthenticatedSocket,
//   ) {
//     console.log('onTypingStart');
//     console.log(client.rooms);
//     client.to(`conversation=${data.roomId}`).emit('onTypingStart');
//   }

//   @SubscribeMessage('onTypingStop')
//   onTypingStop(
//     @MessageBody() data: any,
//     @ConnectedSocket() client: AuthenticatedSocket,
//   ) {
//     console.log('onTypingStop');
//     client.to(`conversation-${data.roomId}`).emit('onTypingStop');
//   }
// }
