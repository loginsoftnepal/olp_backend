import { IoAdapter } from '@nestjs/platform-socket.io';
import { ServerOptions } from 'socket.io';
import * as cookie from 'cookie';
import * as cookieParser from 'cookie-parser';
import { AuthenticatedSocket } from '../utils/interfaces';
import { NextFunction } from 'express';

export class WebSocketAdatpter extends IoAdapter {
  // createIOServer(port: number, options?: ServerOptions): any {
  //   const server = super.createIOServer(port, options);
  //   server.use(async (socket: AuthenticatedSocket, next: NextFunction) => {
  //     console.log('Inside Websocket Adapter');
  //     const { cookie: clientCookie } = socket.handshake;
  //     if (!clientCookie) {
  //       console.log('Client has no cookies');
  //       return next(new Error('Not Authenticated. No Cookies were sent'));
  //     }
  //   });
  // }
}
