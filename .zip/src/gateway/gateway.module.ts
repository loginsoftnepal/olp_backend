import { Module } from '@nestjs/common';
import { ConnectionModule } from 'src/connection/connection.module';
import { GatewaySessionManager } from './gateway.session';

@Module({
  imports: [ConnectionModule],
  providers: [GatewaySessionManager],
  exports: [GatewaySessionManager],
})
export class GatewayModule {}
