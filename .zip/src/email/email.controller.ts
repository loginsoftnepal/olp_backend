import { Controller } from '@nestjs/common';

@Controller('email')
export class EmailController {}
