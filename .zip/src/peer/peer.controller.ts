import { Controller } from '@nestjs/common';

@Controller('peer')
export class PeerController {}
