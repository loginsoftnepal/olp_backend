export default class UpdatePostDto {
  id: number;
  content: string;
  title: string;
}
