export default class CreatePostDto {
  content: string;
  title: string;
}
