export interface Posts {
  id: number;
  content: string;
  title: string;
}
